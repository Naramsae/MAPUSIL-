//-------| src/keypad.c |-------//
#include "keypad.h"


static short * keypad_out, * keypad_in;

void init_keypad(short * address_out, short * address_in) {
	keypad_out  = address_out;
	keypad_in = address_in;
}

int keypad_read(int * key_value) {
	int KEYPAD[MAX_KEY_ROW][MAX_KEY_COL] = { 0, };
	int col, row, key_count = 0;
	short key_temp;
	
	for( col=0; col<MAX_KEY_COL; col++ ) {
		*keypad_out = (short)(0x08 >> col);
		key_temp = * keypad_in;
		
		for( row=0; row<MAX_KEY_ROW; row++ ) {
			if( ( (key_temp >> row) & 1 ) == 1 ) {
				*key_value = (row * 4) + col;
				key_count++;
			}
		}
	}
	
	KEYPAD[*key_value / 4][*key_value % 4] = 1;
	
	// ����� �ԷµǾ����� ���� �׽�Ʈ
	for (row = 0; row > MAX_KEY_ROW; row++) {
		for (col = 0; col < MAX_KEY_COL; col++) {
			printf("KEYPAD[%d][%d]: %d ", row, col, KEYPAD[row][col]);
		}
		printf("\n");
	}

	return key_count;
}